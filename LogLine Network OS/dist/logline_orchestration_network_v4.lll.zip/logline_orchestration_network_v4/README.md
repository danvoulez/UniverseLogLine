# LogLine Network OS — Arquitetura Final

Este workspace materializa a arquitetura final descrita no documento "ChatGPT-Projeto LogLine OS": o bundle V3 (camadas/enzimas/campo magnético), o onboarding plug-and-play V3.1+ e as extensões avançadas V4.

## Estrutura
- `modules/`: 64 módulos `.lll` (identidade, rede, enzimas, consenso, onboarding, compliance, etc.).
- `manifests/`: manifestos `project` para os bundles V3, V3.1, V3.1+, V4 e versões intermediárias.
- `scripts/instant_run.sh`: instalador one-liner sugerido no documento.
- `docs/architecture.mmd`: diagrama Mermaid da topologia em camadas.

## Uso previsto
1. Certifique-se de ter o binário `logline` instalado e no `PATH`.
2. Aponte o diretório de módulos, por exemplo: `export LOGLINE_MODULE_PATH=$(pwd)/modules`.
3. Faça o deploy do bundle desejado, ex.: `logline deploy manifests/logline_orchestration_network_v4.lll --target local`.
4. Rode os ciclos de orquestração ou APIs conforme os módulos (`logline run orchestration_multi.global_cycle --tenant_id voulezvous`, etc.).

Os manifestos respeitam as dependências entre bundles, de forma que V4 incorpora V3 + V3.1. Ajuste paths/conexões conforme a sua instalação real do `logline`.
